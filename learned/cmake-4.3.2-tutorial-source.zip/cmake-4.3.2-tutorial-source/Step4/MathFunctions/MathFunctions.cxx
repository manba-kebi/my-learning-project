// TODO5: Include <cmath>

#include <format>
#include <iostream>

namespace {
// a hack square root calculation using simple operations
double mysqrt(double x)
{
  if (x <= 0) {
    return 0;
  }

  double result = x;

  // do ten iterations
  for (int i = 0; i < 10; ++i) {
    if (result <= 0) {
      result = 0.1;
    }
    double delta = x - (result * result);
    result = result + 0.5 * delta / result;

    std::cout << std::format("Computing sqrt of {} to be {}\n", x, result);
  }
  return result;
}
}

namespace mathfunctions {
double sqrt(double x)
{
  // TODO6: Check if TUTORIAL_USE_STD_SQRT is defined, if so use std::sqrt
  //        instead of mysqrt

  return mysqrt(x);
}
}
